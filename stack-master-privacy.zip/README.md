# Stack Master: Billet Yard — Privacy Policy

Privacy policy for **Stack Master: Billet Yard**, a hyper-casual mobile puzzle game by BLT Innovations LLC.

This page is hosted via GitHub Pages and serves as the official privacy policy URL for Apple App Store and Google Play Store submissions.

**Live URL:** `https://[your-github-username].github.io/stack-master-privacy/`

## Setup

1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Set source to **Deploy from a branch**
4. Select **main** branch, root (`/`)
5. Save — your policy will be live within a few minutes

## Details

- **Game:** Stack Master: Billet Yard
- **Developer:** BLT Innovations LLC
- **Ad Network:** Google AdMob
- **Version:** 2.0
- **Effective Date:** March 17, 2026

## Files

- `index.html` — The full privacy policy (self-contained, no external dependencies except Google Fonts)
